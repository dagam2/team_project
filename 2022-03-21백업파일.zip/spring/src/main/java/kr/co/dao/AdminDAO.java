package kr.co.dao;

public interface AdminDAO {
	//오늘 가입한 회원 수
	public int Ddaymember();
	// 전체 회원수
	public int Countmember();
	
	//오늘 작성한 후기 수
	public int Ddayboard();
	
	//전체 후기 수
	public int Countboard();
}
