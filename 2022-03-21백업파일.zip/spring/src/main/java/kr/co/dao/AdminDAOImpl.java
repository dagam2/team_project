package kr.co.dao;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class AdminDAOImpl implements AdminDAO {

	@Autowired
	private SqlSession sqlSession;
	
	//오늘 가입한 회원 수
	@Override
	public int Ddaymember() {
		return sqlSession.selectOne("adminMapper.Ddaymember");
	}
	@Override
	public int Countmember() {
		return sqlSession.selectOne("adminMapper.Countmember");
	}
	//오늘 작성한 후기 수
	@Override
	public int Ddayboard() {
		return sqlSession.selectOne("adminMapper.Ddayboard");
	}
	@Override
	public int Countboard() {
		return sqlSession.selectOne("adminMapper.Countboard");
	}
}
