package kr.co.dao;





import java.util.List;

import kr.co.vo.Criteria;
import kr.co.vo.MemberVO;

public interface MemberDAO {
	//회원가입
	public void register(MemberVO vo) throws Exception;
	
	//로그인
	public MemberVO login(MemberVO vo) throws Exception;
	
	// 회원정보 수정
	public void memberUpdate(MemberVO vo) throws Exception;
	
	// 회원 탈퇴
	public void memberDelete(MemberVO vo) throws Exception;
	
	// 패스워드 체크
	public int passChk(MemberVO vo) throws Exception;
	
	// 아이디 중복체크
	public int idChk(MemberVO vo) throws Exception;
	
	// 회원 목록 조회
	public List<MemberVO> list(Criteria cri) throws Exception;
	
	// 회원 조회
	public MemberVO read(int mno) throws Exception;
	
	public int Count() throws Exception;
	
	//관리자 회원 삭제
	public void adminmemberDelete(MemberVO vo) throws Exception;
	
	
}
