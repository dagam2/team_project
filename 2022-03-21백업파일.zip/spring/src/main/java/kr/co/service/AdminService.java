package kr.co.service;





import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

@Service
public interface AdminService {

	//결산
	public void summary( Model model);
	
	
}
