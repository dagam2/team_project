package kr.co.service;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import kr.co.dao.AdminDAO;


@Service
public class AdminServiceImpl implements AdminService {
	

	
	
	@Inject
	private AdminDAO dao;
	

	@Override
	public void summary( Model model) {
		 dao.Ddaymember();
		
	}

}
