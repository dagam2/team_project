package kr.com.controller;


import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.co.dao.AdminDAO;

//https://dlgkstjq623.tistory.com/366?category=786635
@Controller

public class AdminController {
	@Autowired
	AdminDAO adminDAO;

	private static final Logger logger = LoggerFactory.getLogger(AdminController.class);
	
	
	// 관리자 메인 페이지 이동
			@RequestMapping(value="/admin/index", method=RequestMethod.GET)
			public void adminMainGet() throws Exception {
				logger.info("관리자 페이지 이동");
				
				
			}
			@RequestMapping(value="/admin/summry", method=RequestMethod.GET)
			public void summary(Model model) {
				int Ddaymember = adminDAO.Ddaymember();
				int Countmember = adminDAO.Countmember();
				int Ddayboard = adminDAO.Ddayboard();
				int Countboard = adminDAO.Countboard();
				model.addAttribute("Ddaymember", Ddaymember);
				model.addAttribute("Countmember", Countmember);
				model.addAttribute("Ddayboard",Ddayboard);
				model.addAttribute("Countboard",Countboard);
				logger.info("관리자 페이지 이동");
				
				
			}
			

	

	

}
