CREATE TABLE MP_BOARD(
    BNO int NOT NULL AUTO_INCREMENT PRIMARY KEY,
    TITLE VARCHAR(100)     NOT NULL,
    CONTENT VARCHAR(2000)  NOT NULL,
    WRITER VARCHAR(100)    NOT NULL,
    REGDATE date default (current_date)
)engine=InnoDB default character set = utf8mb4;
INSERT INTO MP_BOARD( TITLE, CONTENT, WRITER)
     VALUES ('제목입니다', '내용입니다', '홍길동');
     alter table mp_board auto_increment = 0;
set @count =0;
UPDATE MP_BOARD SET MP_BOARD.bno = @COUNT:=@COUNT+1;

select * from mp_board;

select bno,
		title,
        content,
        writer,
        regdate
from (
	select bno,
			title,
            content,
            writer,
            regdate,
            row_number() over(order by bno desc) as rNum
            from mp_board
            ) mp
where rNum between 1 and 10
order by bno desc;

create table mp_reply (
    bno int not null ,
    rno  int NOT NULL AUTO_INCREMENT PRIMARY KEY,
    content varchar(1000) not null,
    writer varchar(50) not null,
    regdate date default (current_date)
)engine=InnoDB default character set = utf8mb4;

alter table mp_reply add constraint mp_reply_bno foreign key(bno)
references mp_board(bno) on delete cascade;

alter table mp_reply drop constraint mp_reply_bno;
insert into mp_reply(bno,  content, writer)
    values(1, '테스트댓글', '테스트 작성자');
    
     select rno, content, writer, regdate
  from mp_reply
 where bno = 1;
 
 create table exam.MP_MEMBER(
 	mno int NOT NULL AUTO_INCREMENT PRIMARY KEY ,
	userId varchar(40) not null ,
	userPass varchar(100) not null,
    userName varchar(40) not null,
    userMail varchar(100) not null,
    userGender  varchar(3) not null,
	regDate date default (current_date)
	)engine=InnoDB default character set = utf8mb4;
    
drop table mp_member;

select * from mp_member;

 alter table mp_board add(hit int default 0);

	  
	   alter table mp_member add(newsletter int default 0);
      update mp_member set adminChk ='1' where userId='kosmo';
      
create table area (
	seq int primary key,
	area varchar(20) not null,
    area_eng varchar(20) not null,
    loc_x varchar(20) not null,
    loc_y varchar(20) not null,
    content varchar(150),
    hashtag varchar(50),
    cnt int default 0
) engine=InnoDB default character set = utf8mb4;

insert into area (seq, area, area_eng, loc_x, loc_y, content, hashtag)
 values(1, '제주', 'JEJU', '33.3590628', '126.534361', '대한민국 대표 휴양지', "#섭지코지 #비자림");
 
  
create table place (
	seq int primary key,
	name varchar(20) not null,
    loc_x varchar(20) not null,
    loc_y varchar(20) not null,
    content varchar(150),
    category varchar(20) not null,
    area varchar(20) not null,
    cnt int default 0
) engine=InnoDB default character set = utf8mb4;


select count(*) from mp_member where regDate = curdate();
select count(*) from mp_member;

select curdate();

select count(*) from mp_board where regDate = curdate();
select count(*) from mp_board;