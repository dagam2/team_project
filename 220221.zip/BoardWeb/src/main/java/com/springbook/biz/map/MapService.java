package com.springbook.biz.map;

import java.util.List;

public interface MapService {
	
	void insertMap(MapVO vo);
	void updateMap(MapVO vo);
	void deleteMap(MapVO vo);
	MapVO getMap(MapVO vo);
	List<MapVO> getMapList(MapVO vo);

}
