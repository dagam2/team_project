package com.springbook.biz.map;

//VO(Value Object)
public class MapVO {

	private int seq;
	private String name;
	private String loc_x;
	private String loc_y;
	private String content;
	private String category;
	private String area;
	private int cnt;
	private String searchCondition;
	private String searchKeyword;
	public int getSeq() {
		return seq;
	}
	public void setSeq(int seq) {
		this.seq = seq;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLoc_x() {
		return loc_x;
	}
	public void setLoc_x(String loc_x) {
		this.loc_x = loc_x;
	}
	public String getLoc_y() {
		return loc_y;
	}
	public void setLoc_y(String loc_y) {
		this.loc_y = loc_y;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public int getCnt() {
		return cnt;
	}
	public void setCnt(int cnt) {
		this.cnt = cnt;
	}
	public String getSearchCondition() {
		return searchCondition;
	}
	public void setSearchCondition(String searchCondition) {
		this.searchCondition = searchCondition;
	}
	public String getSearchKeyword() {
		return searchKeyword;
	}
	public void setSearchKeyword(String searchKeyword) {
		this.searchKeyword = searchKeyword;
	}
	@Override
	public String toString() {
		return "MapVO [seq=" + seq + ", name=" + name + ", loc_x=" + loc_x + ", loc_y=" + loc_y + ", content=" + content
				+ ", category=" + category + ", area=" + area + ", cnt=" + cnt + "]";
	}
	
	
	
}
