package com.springbook.biz.map.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.springbook.biz.map.MapVO;

//DAO(Data Access Object)
@Repository
public class MapDAOSpring {
	@Autowired
	private JdbcTemplate jdbcTemplate;

	// SQL ���ɾ�
	private final String MAP_INSERT = "insert into map(seq, name, loc_x, loc_y, content, category, area) "
			+ "values((select ifnull(max(seq), 0) +1 from map m), ?, ?, ?, ?, ?, ?)";
	private final String MAP_UPDATE = "update map set name=?, content=?, category=?, area=? where seq=?";
	private final String MAP_DELETE = "delete from map where seq=?";
	private final String MAP_GET = "select * from map where seq=?";
	private final String MAP_LIST = "select * from map where name like concat('%', ?,'%') order by seq desc";
	private final String MAP_LIST_N = "select * from map where name like concat('%', ?,'%') order by seq desc";
	private final String MAP_LIST_A = "select * from map where area like concat('%', ?,'%') order by seq desc";

	// CRUD ����� �޼ҵ� ����
		// �� ���
		public void insertMap(MapVO vo) {
			jdbcTemplate.update(MAP_INSERT, vo.getName(), vo.getLoc_x(), vo.getLoc_y(), vo.getContent(), vo.getCategory());
		}

		// �� ����
		public void updateMap(MapVO vo) {
			jdbcTemplate.update(MAP_UPDATE, vo.getName(), vo.getContent(), vo.getCategory(), vo.getArea(), vo.getSeq());
		}

		// �� ����
		public void deleteMap(MapVO vo) {
			jdbcTemplate.update(MAP_DELETE, vo.getSeq());
		}

		// �� �� ��ȸ
		public MapVO getMap(MapVO vo) {
			Object[] args = { vo.getSeq() };
			return jdbcTemplate.queryForObject(MAP_GET, args, new MapRowMapper());
		}

		// �� ��� ��ȸ
		public List<MapVO> getMapList(MapVO vo) {
			Object[] args = { vo.getSearchKeyword() };
			if(vo.getSearchCondition().equals("NAME")) {
				return jdbcTemplate.query(MAP_LIST_N, args, new MapRowMapper());
			} else if(vo.getSearchCondition().equals("AREA")) {
				return jdbcTemplate.query(MAP_LIST_A, args, new MapRowMapper());
			}
			return null;
		}
	}

	class MapRowMapper implements RowMapper<MapVO> {
		

		@Override
		public MapVO mapRow(ResultSet rs, int rowNum) throws SQLException {
			MapVO map = new MapVO();
			map.setSeq(rs.getInt("SEQ"));
			map.setName(rs.getString("NAME"));
			map.setLoc_x(rs.getString("LOC_X"));
			map.setLoc_y(rs.getString("LOC_Y"));
			map.setContent(rs.getString("CONTENT"));
			map.setCategory(rs.getString("CATEGORY"));
			map.setArea(rs.getString("AREA"));
			map.setCnt(rs.getInt("CNT"));
			return map;
		}

}
