package com.springbook.biz.map.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springbook.biz.board.BoardVO;
import com.springbook.biz.map.MapService;
import com.springbook.biz.map.MapVO;

@Service("mapService")
public class MapServiceImpl implements MapService {
	@Autowired
	private MapDAOSpring mapDAO; 

	@Override
	public void insertMap(MapVO vo) {
//		//�׽�Ʈ�� ���� �߻��ڵ�
//		if(vo.getSeq() == 0) {
//			throw new IllegalArgumentException("0�� ���� ����� �� �����ϴ�.");
//		}
		mapDAO.insertMap(vo);
		
	}

	@Override
	public void updateMap(MapVO vo) {
		mapDAO.updateMap(vo);
		
	}

	@Override
	public void deleteMap(MapVO vo) {
		mapDAO.deleteMap(vo);
		
	}

	@Override
	public MapVO getMap(MapVO vo) {
		return mapDAO.getMap(vo);
	}

	@Override
	public List<MapVO> getMapList(MapVO vo) {
		return mapDAO.getMapList(vo);
	}
	
}
