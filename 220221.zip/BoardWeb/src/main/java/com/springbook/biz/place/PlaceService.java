package com.springbook.biz.place;

import java.util.List;

public interface PlaceService {
	
	void insertPlace(PlaceVO vo);
	void updatePlace(PlaceVO vo);
	void deletePlace(PlaceVO vo);
	PlaceVO getPlace(PlaceVO vo);
	List<PlaceVO> getPlaceList(PlaceVO vo);

}
