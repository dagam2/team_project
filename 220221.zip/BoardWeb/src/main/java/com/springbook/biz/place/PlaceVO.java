package com.springbook.biz.place;

//VO(Value Object)
public class PlaceVO {

	private int seq;
	private String area;
	private String area_eng;
	private String loc_x;
	private String loc_y;
	private String content;
	private String hashtag;
	private int cnt;
	public int getSeq() {
		return seq;
	}
	public void setSeq(int seq) {
		this.seq = seq;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getArea_eng() {
		return area_eng;
	}
	public void setArea_eng(String area_eng) {
		this.area_eng = area_eng;
	}
	public String getLoc_x() {
		return loc_x;
	}
	public void setLoc_x(String loc_x) {
		this.loc_x = loc_x;
	}
	public String getLoc_y() {
		return loc_y;
	}
	public void setLoc_y(String loc_y) {
		this.loc_y = loc_y;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getHashtag() {
		return hashtag;
	}
	public void setHashtag(String hashtag) {
		this.hashtag = hashtag;
	}
	public int getCnt() {
		return cnt;
	}
	public void setCnt(int cnt) {
		this.cnt = cnt;
	}
	@Override
	public String toString() {
		return "PlaceVO [seq=" + seq + ", area=" + area + ", area_eng=" + area_eng + ", loc_x=" + loc_x + ", loc_y="
				+ loc_y + ", content=" + content + ", hashtag=" + hashtag + ", cnt=" + cnt + "]";
	}
	
	
	
}
