package com.springbook.biz.place.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.springbook.biz.map.MapVO;
import com.springbook.biz.place.PlaceVO;

//DAO(Data Access Object)
@Repository
public class PlaceDAOSpring {
	@Autowired
	private JdbcTemplate jdbcTemplate;

	// SQL ���ɾ�
	private final String PLACE_INSERT = "insert into place(seq, area, area_eng, loc_x, loc_y, content, hashtag)"
			+ "values((select ifnull(max(seq), 0) +1 from place p), ?, ?, ?, ?, ?, ?)";
	private final String PLACE_UPDATE = "update place set area=?, area_eng=?, content=?, hashtag=? where seq=?";
	private final String PLACE_DELETE = "delete from place where seq=?";
	private final String PLACE_GET = "select * from place where seq=?";
	private final String PLACE_LIST = "select * from place order by seq desc";


	// CRUD ����� �޼ҵ� ����
		// �� ���
		public void insertPlace(PlaceVO vo) {
			jdbcTemplate.update(PLACE_INSERT, vo.getArea(), vo.getArea_eng(), vo.getLoc_x(), vo.getLoc_y(), vo.getContent(), vo.getHashtag());
		}

		// �� ����
		public void updatePlace(PlaceVO vo) {
			jdbcTemplate.update(PLACE_UPDATE, vo.getArea(), vo.getArea_eng(), vo.getContent(), vo.getHashtag(), vo.getSeq());
		}

		// �� ����
		public void deletePlace(PlaceVO vo) {
			jdbcTemplate.update(PLACE_DELETE, vo.getSeq());
		}

		// �� �� ��ȸ
		public PlaceVO getPlace(PlaceVO vo) {
			Object[] args = { vo.getSeq() };
			return jdbcTemplate.queryForObject(PLACE_GET, args, new PlaceRowMapper());
		}

		// �� ��� ��ȸ
		public List<PlaceVO> getPlaceList(PlaceVO vo) {
			return jdbcTemplate.query(PLACE_LIST, new PlaceRowMapper());
		}
	}

	class PlaceRowMapper implements RowMapper<PlaceVO> {
		

		@Override
		public PlaceVO mapRow(ResultSet rs, int rowNum) throws SQLException {
			PlaceVO place = new PlaceVO();
			place.setSeq(rs.getInt("SEQ"));
			place.setArea(rs.getString("AREA"));
			place.setArea_eng(rs.getString("AREA_ENG"));
			place.setLoc_x(rs.getString("LOC_X"));
			place.setLoc_y(rs.getString("LOC_Y"));
			place.setContent(rs.getString("CONTENT"));
			place.setHashtag(rs.getString("HASHTAG"));
			place.setCnt(rs.getInt("CNT"));
			return place;
		}

}
