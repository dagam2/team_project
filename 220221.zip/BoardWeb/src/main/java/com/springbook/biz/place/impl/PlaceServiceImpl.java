package com.springbook.biz.place.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springbook.biz.place.PlaceService;
import com.springbook.biz.place.PlaceVO;

@Service("placeService")
public class PlaceServiceImpl implements PlaceService {
	@Autowired
	private PlaceDAOSpring placeDAO; 

	@Override
	public void insertPlace(PlaceVO vo) {
//		//�׽�Ʈ�� ���� �߻��ڵ�
//		if(vo.getSeq() == 0) {
//			throw new IllegalArgumentException("0�� ���� ����� �� �����ϴ�.");
//		}
		placeDAO.insertPlace(vo);
		
	}

	@Override
	public void updatePlace(PlaceVO vo) {
		placeDAO.updatePlace(vo);
		
	}

	@Override
	public void deletePlace(PlaceVO vo) {
		placeDAO.deletePlace(vo);
		
	}

	@Override
	public PlaceVO getPlace(PlaceVO vo) {
		return placeDAO.getPlace(vo);
	}

	@Override
	public List<PlaceVO> getPlaceList(PlaceVO vo) {
		return placeDAO.getPlaceList(vo);
	}
	
}
