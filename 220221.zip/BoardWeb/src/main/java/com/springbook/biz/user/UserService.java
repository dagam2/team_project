package com.springbook.biz.user;

public interface UserService {
	public UserVO getUser(UserVO vo);
}
