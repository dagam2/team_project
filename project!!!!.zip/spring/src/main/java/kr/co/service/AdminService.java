package kr.co.service;



import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import kr.co.vo.MemberVO;

@Service
public interface AdminService {

	MemberVO read(String userId) throws Exception;

}
