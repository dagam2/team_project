package kr.co.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import kr.co.dao.MemberDAO;
import kr.co.vo.MemberVO;

@Service
public class AdminServiceImpl implements AdminService {
	
	@Autowired
	MemberDAO memberDAO;
	
	

	@Override
	public MemberVO read(String userId) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
