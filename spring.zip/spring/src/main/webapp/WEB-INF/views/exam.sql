create table exam.users (
	id varchar(20) primary key,
    password varchar(20) not null,
    name varchar(20) not null,
    role varchar(20)
) engine=InnoDB default character set = utf8mb4;

insert into users values('test', 'test123', '관리자', 'Admin');
insert into users values('user1', 'user1', '홍길동', 'User');



CREATE TABLE MP_BOARD(
    BNO int NOT NULL AUTO_INCREMENT PRIMARY KEY,
    TITLE VARCHAR(100)     NOT NULL,
    CONTENT VARCHAR(2000)  NOT NULL,
    WRITER VARCHAR(100)    NOT NULL,
    REGDATE date default (current_date)
)engine=InnoDB default character set = utf8mb4;
INSERT INTO MP_BOARD( TITLE, CONTENT, WRITER)
     VALUES ('제목입니다', '내용입니다', 'MELONPEACH');
     alter table mp_board auto_increment = 0;
set @count =0;
UPDATE MP_BOARD SET MP_BOARD.bno = @COUNT:=@COUNT+1;

select * from mp_board;


update mp_board set title ='안녕하세요' where bno=1;
delete from mp_board where bno=20;

select bno,
		title,
        content,
        writer,
        regdate
from (
	select bno,
			title,
            content,
            writer,
            regdate,
            row_number() over(order by bno desc) as rNum
            from mp_board
            ) mp
where rNum between 1 and 10
order by bno desc;

create table mp_reply (
    bno int not null ,
    rno  int NOT NULL AUTO_INCREMENT PRIMARY KEY,
    content varchar(1000) not null,
    writer varchar(50) not null,
    regdate date default (current_date)
)engine=InnoDB default character set = utf8mb4;

alter table mp_reply add constraint mp_reply_bno foreign key(bno)
references mp_board(bno);

insert into mp_reply(bno,  content, writer)
    values(1, '테스트댓글', '테스트 작성자');
    
    select rno, content, writer, regdate
  from mp_reply
 where bno = 1;

 create table exam.MP_MEMBER(
	userId varchar(40) not null primary key,
	userPass varchar(100) not null,
    userName varchar(40) not null,
    userMail varchar(100) not null,
    userGender  varchar(3) not null,
	regDate date default (current_date)
	)engine=InnoDB default character set = utf8mb4;